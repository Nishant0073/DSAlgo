/*
sub: Data Structure
Roll No: 2125
Exp. No:13
Que. BST implementation
*/

#include<stdio.h>
#include<stdlib.h>
typedef struct BST Node;

struct BST{

	int data;
	Node *left;
	Node *right;
};

 Node* getNode(int data){

	Node *node = malloc(sizeof(Node));
	node->data = data;
	node->left = NULL;
	node->right = NULL;

	return node;
}
int search(Node *root,int data){

	if(root==NULL){

		return 0;
	}
	else{

		if(root->data==data){
			return 1;
		}
		else{

			if(root->data > data)
				search(root->left,data);
			else
				search(root->right,data);
		}
	}

}


void insert(Node *root,int data){

	if(root->data > data){

		if(root->left==NULL){

			Node *node = getNode(data);
			root->left=node;
			return;
		}
		else{

			insert(root->left,data);
		}
	}
	else{

		if(root->right ==  NULL){
			Node *node = getNode(data);
			root->right = node;
			return;
		}
		else{

			insert(root->right,data);
		}
	}

}

Node* findMinimum(Node* cur)  
{  
    while(cur->left != NULL) {  
        cur = cur->left;  
    }  
    return cur;  
}  



void deletion(Node* root, int item)  
{  
    Node* parent = NULL;  
    Node* cur = root;  
  
    int isValid=search(cur, item);  
    if(isValid==0)
    {
    	printf("%d is not present in tree.\n",item );
    	return;
    }
    if (cur == NULL)  
        return;  
  
    if (cur->left == NULL && cur->right == NULL)  
    {  
        if (cur != root)  
        {  
            if (parent->left == cur)  
                parent->left = NULL;  
            else  
                parent->right = NULL;  
        }  
        else  
            root = NULL;  
  
        free(cur);       
    }  
    else if (cur->left && cur->right)  
    {  
        Node* succ  = findMinimum(cur->right);  
  
        int val = succ->data;  
  
        deletion(root, succ->data);  
  
        cur->data = val;  
    }  
  
    else  
    {  
        Node* child = (cur->left)? cur->left: cur->right;  
  
        if (cur != root)  
        {  
            if (cur == parent->left)  
                parent->left = child;  
            else  
                parent->right = child;  
        }  
  
        else  
            root = child;  
        free(cur);  
    }  
}  
  

void inorder(Node *root){
	
	if(root == NULL){
		return;
	}

	inorder(root->left);
	printf("%d ",root->data );
	inorder(root->right);
}



int main(){

	Node *root = malloc(sizeof(Node));
	root->left=NULL;
	root->right=NULL;
	printf("Enter the root element of tree:\n");
	scanf("%d",&root->data);
	int data;

	while(1){
		int choise;
		printf("Enter the option:\n1)Insert Node in tree\n2)Search the element in tree\n3)Delete element in tree\n4)Inorder Traversal\n5)exit\n:");
		scanf("%d",&choise);
		int exit=0;

		switch(choise){
			case 1:
				printf("Enter the data to Insert in tree:\n");
				scanf("%d",&data);
				insert(root,data);
				break;
			case 2:
				printf("Enter the element to search:\n");
				scanf("%d",&data);
				int temp=search(root,data);
				if(temp==1)
					printf("%d is found in tree\n",data );
				else
					printf("%d is not found in tree\n",data );
				break;
			case 3:
				printf("Enter the element to delete:");
				scanf("%d",&data);
				deletion(root, data);
				break;
			case 4:
				inorder(root);
				break;
			case 5:
				exit=1;
		}

		if(exit==1){
			break;
		}

	}
}