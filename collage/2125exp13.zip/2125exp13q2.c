/*
sub: Data Structure
Roll No: 2125
Exp. No:13
Que. Given a Binary Tree, find sum of all left leaves in it. For example, sum of all left leaves in below Binary Tree is 5+1=6.
*/

#include<stdio.h>
#include<stdlib.h>
typedef struct BST Node;

struct BST{

	int data;
	Node *left;
	Node *right;
};

 Node* getNode(int data){

	Node *node = malloc(sizeof(Node));
	node->data = data;
	node->left = NULL;
	node->right = NULL;

	return node;
}
int search(Node *root,int data){

	if(root==NULL){

		return 0;
	}
	else{

		if(root->data==data){
			return 1;
		}
		else{

			if(root->data > data)
				search(root->left,data);
			else
				search(root->right,data);
		}
	}

}


void insert(Node *root,int data){

	if(root->data > data){

		if(root->left==NULL){

			Node *node = getNode(data);
			root->left=node;
			return;
		}
		else{

			insert(root->left,data);
		}
	}
	else{

		if(root->right ==  NULL){
			Node *node = getNode(data);
			root->right = node;
			return;
		}
		else{

			insert(root->right,data);
		}
	}

}

int getsum(Node *root,int ans)
{
	if(root->left==NULL || root==NULL  || root->right == NULL)
	{
		return ans;
	}

	if(root->left->right==NULL && root->left->left==NULL)
	{
		return(ans+=root->left->data);
	}
	
		return(getsum(root->left,ans));
		return(getsum(root->right,ans));
	
}

void inorder(Node *root){
	
	if(root == NULL){
		return;
	}

	inorder(root->left);
	printf("%d ",root->data );
	inorder(root->right);
}



int main(){

	Node *root = malloc(sizeof(Node));
	root->left=NULL;
	root->right=NULL;
	printf("Enter the root element of tree:\n");
	scanf("%d",&root->data);
	int data;

	while(1){
		int choise;
		printf("Enter the option:\n1)Insert Node in tree\n2)Get sum of all left leaf Nodes\n3)Inorder Traversal\n4)exit\n:");
		scanf("%d",&choise);
		int exit=0;
		int ans=0;

		switch(choise){
			case 1:
				printf("Enter the data to Insert in tree:\n");
				scanf("%d",&data);
				insert(root,data);
				break;
			case 2:
				ans=getsum(root, ans);
				printf("The sum of all left leaves node is %d,\n",ans );
				exit=1;
				break;
			case 3:
				inorder(root);
				break;
			case 4:
				exit=1;
		}

		if(exit==1){
			break;
		}

	}
}