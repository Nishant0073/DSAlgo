
/*Sub. : Data Structure
Div. : B (SYCSE);
Roll No.: 2125
*/

#include<stdio.h>

int start = 0;
int end = 0;
int queue[10000];

void push()
{
	int data;
	if (end == 10000)
	{
		printf("The queue is Full.\n");
	}
	else
	{
		printf("Enter the element to be pushed:\n");
		scanf("%d", &data);

		queue[end] = data;
		end++;
	}
}

void pop()
{
	if (start == end)
	{
		printf("The queue is empty.\n");
	}
	else
	{
		int data = queue[start];
		start++;
		printf("The %d element from queue is poped.\n", data);
	}

}

void top()
{
	if (start==end)
	{
		printf("The queue is empty\n");
	}
	else
	{
		printf("The element at the top od queue is : %d\n", queue[start] );
	}
}


int main()
{
	printf("Queue using array\n");
	int n = 0;
	do
	{
		int op = 4;
		printf("Enter the option:\n");
		printf("1)Push element\n2)Pop element\n3)Element at the top.\n4)break\n::");
		scanf("%d", &op);

		switch (op)
		{
		case 1 : push();
			break;
		case 2: pop();
			break;
		case 3: top();
			break;
		case 4: n = 1;
			break;
		default:
			printf("Enter Valid options.!!!!!!\n");
		}

	}
	while (n != 1);
	return 0;
}