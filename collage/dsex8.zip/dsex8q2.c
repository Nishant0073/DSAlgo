#include <stdio.h>

#define SIZE 1000

int queue[SIZE];
int start = -1, end = -1;

int isFull() {
    if ((start == end + 1) || (start == 0 && end == SIZE - 1)) return 1;
    return 0;
}

int isEmpty() {
    if (start == -1) return 1;
    return 0;
}


void push() {

    if (isFull())
        printf("\n Queue is full!! \n");
    else {
        int element;
        printf("Enter the element\n");
        scanf("%d", &element);
        if (start == -1) start = 0;
        end = (end + 1) % SIZE;
        queue[end] = element;
    }
}


int pop() {
    int element;
    if (isEmpty()) {
        printf("\n Queue is empty !! \n");
        return (-1);
    } else {
        element = queue[start];
        if (start == end)
        {
            start = -1;
            end = -1;
        }

        else
        {
            start = (start + 1) % SIZE;
        }
        printf("The %d element from queue is poped.\n", element);
        return (element);
    }
}


int main()
{
    printf("Queue using array\n");
    int n = 0;
    do
    {
        int op = 4;
        printf("Enter the option:\n");
        printf("1)Push element\n2)Pop element\n3)break\n::");
        scanf("%d", &op);

        switch (op)
        {
        case 1 : push();
            break;
        case 2: pop();
            break;
        case 3: n = 1;
            break;
        default:
            printf("Enter Valid options.!!!!!!\n");
        }

    }
    while (n != 1);
    return 0;
}